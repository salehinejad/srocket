import numpy as np
# NS = 5
# D = 4
# S = np.round(np.random.random((D,NS)))

# parents = np.asarray([np.random.permutation(np.arange(NS))[:3] for i in range(NS)])
# F_thr = 0.7
# F = np.random.random((D,NS))<F_thr
# mask = np.logical_and(F,np.logical_or(S[:,parents[:,1]], S[:,parents[:,2]]))

# ev = (1-S[:,parents[:,0]])*mask + S[:,parents[:,0]]*np.logical_not(mask)

# crossover_rate = 0.9                # Recombination rate [0,1] - larger more diverisyt
# cr = (np.random.rand(D,NS)<crossover_rate)
# mut_keep = ev*cr
# pop_keep = S*np.logical_not(cr)
# new_population = mut_keep + pop_keep
# print(new_population,S)
# #  keeps_mask = (np.abs(1*x2-1*x3)==0)*F_mask #np.logical_not(F_mask) # genes to keep  - not of F-mask to keep
# #     ev = np.multiply(np.logical_not(F_mask),x1) + np.multiply(keeps_mask,(1-x1))
    

a = np.random.random((3,4))
print(np.mean(a))    