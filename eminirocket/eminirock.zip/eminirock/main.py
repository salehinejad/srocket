
import argparse, copy
import numpy as np
import pandas as pd
import time, os, sys, json
from scipy.spatial.distance import cdist
sys.path.insert(0, "utils")
sys.path.insert(0, "utils/minirocket")

import optimization, classifier
from sklearn.linear_model import RidgeClassifierCV
import matplotlib.pyplot as plt
from rocket_functions import generate_kernels, apply_kernels
# from pygsp import graphs, filters, plotting
# import signal_energy
from sklearn.metrics import accuracy_score, confusion_matrix
from tqdm import tqdm
# from graph_spectral import graph_spectral
# from graph_mp import graph_mp, graph_smp
import minirocket

# dataset_names = [i for i in os.listdir('data/') if not i.startswith('.')]
# print(dataset_names)
# collective_results = open('collective_results.csv','w')


# dataset_names = 'Beef'
# model = 'ising' # R S MP SMP
# nk_list = 100 # number of kernels

# == parse arguments ===========================================================

parser = argparse.ArgumentParser()

parser.add_argument("-d", "--ds_name", required = True)
parser.add_argument("-i", "--input_path", required = True)
# parser.add_argument("-o", "--output_path", required = True)
parser.add_argument("-cv", "--num_runs", type = int, default = 1)
parser.add_argument("-m", "--model", required = True)
parser.add_argument("-k", "--num_kernels", type = int, default = 84)
parser.add_argument("-p", "--pop_size", type = int, default = 10000)
parser.add_argument("-e", "--num_epochs", type = int, default = 100)
parser.add_argument("-pm", "--ppvmax", type = str, default = 'ppv') # ppv ppvmax
parser.add_argument("-bm", "--benchmark", type = str, default = 'UCR') # UCR AudioMNIST

parser.add_argument("-t", "--edge_threshold", type = float, default = 0)
arguments = parser.parse_args()

auto_save = False
n_epochs = arguments.num_epochs
NS = arguments.pop_size
Ncv = arguments.num_runs
# model_ = 'MP' # S:Spectral; SMP:MP+Spectral; R:Rocket(original); 
benchmark = arguments.benchmark
ppvmax_mode = arguments.ppvmax
ds_name = arguments.ds_name

# -- read data -------------------------------------------------------------
print("Loading data ...")
if benchmark == 'UCR':
    dataset_path = os.path.join(arguments.input_path,ds_name)
    print(dataset_path)
    # == run =======================================================================
    # dataset_names = np.loadtxt(arguments.dataset_names, "str")
    # dataset_name = dataset_path.split('/')[1]
    print(f"{ds_name}".center(80, "-"))
    results = pd.DataFrame(index = [ds_name],
                        columns = ["accuracy_mean",
                                    "accuracy_standard_deviation",
                                    "time_training_seconds",
                                    "time_test_seconds"],
                        data = 0)
    results.index.name = "dataset"
    # results_output_name = dataset_path+arguments.model+'_K'+str(arguments.num_kernels)+'_Th'+str(arguments.edge_threshold)+'ppv.csv'

    print(f"RUNNING".center(80, "="))

    print(os.path.join(dataset_path,ds_name+"_TRAIN.tsv"))
    training_data = np.loadtxt(os.path.join(dataset_path,ds_name+"_TRAIN.tsv"))
    Y_training, X_training = training_data[:, 0].astype(np.int32), training_data[:, 1:]
    # print(X_training.shape)
    test_data = np.loadtxt(os.path.join(dataset_path,ds_name+"_TEST.tsv"))
    Y_test, X_test = test_data[:, 0].astype(np.int32), test_data[:, 1:]
    # print(Y_training.shape, X_training.shape,Y_test.shape, X_test.shape)
    # (20,) (20, 512) (20,) (20, 512)
elif benchmark == 'AudioMNIST':
    print('Reading AudioMNIST data ...')
    ds_name = benchmark
    wavfiles_path = '/home/hojjat/data/AudioMNIST/data'
    X_training, Y_training, _ = audiomnistreader.readfiles(0,40,wavfiles_path)
    X_test, Y_test, _ = audiomnistreader.readfiles(40,60,wavfiles_path)
print("Done.")

input_length = X_training.shape[-1]
C = np.max(Y_training) # number of classes


### Results collection

_timings = np.zeros([4, Ncv]) # trans. tr., trans. te., training, test


scores_collection = np.zeros((Ncv,n_epochs))
avg_scores_collection = np.zeros((Ncv,n_epochs))

sparsity_collection = np.zeros((Ncv,n_epochs))
avg_sparsity_collection = np.zeros((Ncv,n_epochs))

cost_collection = np.zeros((Ncv,n_epochs))
avg_cost_collection = np.zeros((Ncv,n_epochs))
    
test_results_ = np.zeros((Ncv,26))

# -- run -------------------------------------------------------------------
file_path = 'resultsNP'+str(NS)+'/'+arguments.ds_name

if not os.path.exists(file_path):
    os.makedirs(file_path)
ppvmax_mode = 'ppv'    
print(f"Performing runs...")



for cv_indx in range(Ncv):
    print(X_training.shape,type(X_training))
    X_training = np.asarray(X_training,dtype=np.float32)
    X_test = np.asarray(X_test,dtype=np.float32)

    minirock_prams = minirocket.fit(X_training)
    # kernels_g = kernels[-1]
    # kernels = kernels[0:-1]
    # print('kernels',kernels[0],kernels[0].shape)
    # print('lengths',kernels[1],kernels[1].shape)

    # -- Transform Training ------------------------------------------------
    # time_a = time.perf_counter()
    print('Applying kernels...')
    X_training_transform = minirocket.transform(X_training, minirock_prams) # N_Samples * 2*N_kernels (ppv,max)
    X_test_transform = minirocket.transform(X_test, minirock_prams) 
    graph_signal_tr = X_training_transform
    graph_signal_ts = X_test_transform
    print(X_training_transform.shape)
    arguments.num_kernels = X_training_transform.shape[1]

    # time_b = time.perf_counter()
    # _timings[0, i] = time_b - time_a
    # print('Shapes',X_training.shape,X_training_transform.shape)

    # -- Transform Test ----------------------------------------------------
    # time_a = time.perf_counter()
    # time_b = time.perf_counter()
    # _timings[1, i] = time_b - time_a

    #------ Feature Extraction Model Selection and Construction
    # if arguments.model=='S':
    #     X_training_transform, X_test_transform = graph_spectral(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test)
    # elif arguments.model=='MP':
    #     X_training_transform, X_test_transform, _ = graph_mp(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test)
    # elif arguments.model=='SMP':
    #     X_training_transform, X_test_transform = graph_smp(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test)
    # elif arguments.model=='evolv': # erocket on ppv and max data
    #     X_training_transform = X_training_transform # N_Samples * 2*N_kernels (ppv,max)
    #     X_test_transform = X_test_transform

    ## PPV Only
    # graph_signal_tr = np.expand_dims(X_training_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    # graph_signal_tr = np.reshape(graph_signal_tr,(X_training_transform.shape[0],arguments.num_kernels,2))    
    # graph_signal_tr = graph_signal_tr[:,:,0] # ppv data N,N_kernels
    
    graph_signal_tr_tiled = np.expand_dims(X_training_transform,axis=2)
    graph_signal_tr_tiled = np.tile(graph_signal_tr_tiled,(1,1,NS)) # N_Sample,N_Kernels,N_pop    
    n_samples = X_training_transform.shape[0]

    np.savetxt(file_path+'/'+ppvmax_mode+'_featuresTr.txt',graph_signal_tr, fmt="%f",delimiter=',')
    np.savetxt(file_path+'/'+ppvmax_mode+'_labelsTr.txt',Y_training, fmt="%f",delimiter=',')

    ## Test
    # graph_signal_ts = np.expand_dims(X_test_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    # graph_signal_ts = np.reshape(graph_signal_ts,(X_test_transform.shape[0],arguments.num_kernels,2))
    # graph_signal_ts = graph_signal_ts[:,:,0] # ppv data N,N_kernels

    np.savetxt(file_path+'/'+ppvmax_mode+'_featuresTs.txt',graph_signal_ts, fmt="%f",delimiter=',')
    np.savetxt(file_path+'/'+ppvmax_mode+'_labelsTs.txt',Y_test, fmt="%f",delimiter=',')

    graph_signal_ts_tiled = np.expand_dims(X_test_transform,axis=2)
    graph_signal_ts_tiled = np.tile(graph_signal_ts_tiled,(1,1,NS)) # N_Sample,N_Kernels,N_pop

    ## States Initialization
    S2 = np.round(np.random.random((arguments.num_kernels,NS))) # Num_classes x Num_kernels x Population size
    S = np.ones((arguments.num_kernels,NS)) # Num_classes x Num_kernels x Population size
    S[:,:int(NS/2)] = S2[:,:int(NS/2)]
    S = np.expand_dims(S,axis=0)
    S = np.tile(S,(n_samples,1,1))
    S_full = np.ones((arguments.num_kernels,NS)) # full states
    S_full = np.expand_dims(S_full,axis=0)

    ### Best with respect to individual metrics
    best_score_sofar = [0,0,0] # first element is score, secod is sparsity, third is cost
    best_state_scorewise = []
    best_sparsity_sofar = [0,1,0] # first element is score, secod is sparsity, third is cost
    best_state_sparsitywise = []
    best_score_epoch = 0
    best_sparsity_epoch = 0





    ## Training with full states
    trained_model = classifier.training(X_training_transform,Y_training)
    score_S = classifier.inference(S,trained_model,graph_signal_tr_tiled,Y_training) # inference performance of initialized sparse states
    score_full = classifier.inference(S_full,trained_model,graph_signal_tr_tiled,Y_training) # inference performance of full states
    cost_S, dcost_S = classifier.costting(S,score_S) # cost_S: total cost  dcost_S: dimensionality cost
    # print(cost_S, dcost_S,score_S,score_full)
    print(20*'-')
    print('Max score initial S:',np.max(score_S),' *** Mean score initial S:',np.mean(score_S))
    print('Min cost initial S:',np.min(cost_S),'*** Mean cost initial S:',np.mean(cost_S))
    print('Max score Full S:',np.max(score_full),'*** Mean score full S:',np.mean(score_full))
    print(20*'-')

    ## Optimization
    break_flag = False
    for epoch in range(n_epochs):
        if break_flag==True:
            break
        CS = optimization.evolution(S) # candidate states
        score_CS = classifier.inference(CS,trained_model,graph_signal_tr_tiled,Y_training)
        # print('score_CS',score_CS)
        cost_CS, dcost_CS = classifier.costting(CS,score_CS) # cost_S: total cost  dcost_S: dimensionality cost
        # print(cost_CS, dcost_CS)
        S, S_best, cost_S, cost_S_best, avg_cost_S, score_S, S_score_best = optimization.selection(S,CS,cost_S,cost_CS,score_S,score_CS)
        sparsity_value = np.sum(S_best)/S.shape[1]

        ## Picking best so far
        if epoch == 0:
            best_state_sparsitywise = S_best
            best_state_scorewise = S_best

        if S_score_best>best_score_sofar[0]:
            best_score_sofar[0] = S_score_best
            best_score_sofar[1] = sparsity_value
            best_score_sofar[2] = cost_S_best
            best_state_scorewise = S_best
            best_score_epoch = epoch
        if sparsity_value < best_sparsity_sofar[1]:            
            best_sparsity_sofar[0] = S_score_best
            best_sparsity_sofar[1] = sparsity_value
            best_sparsity_sofar[2] = cost_S_best
            best_state_sparsitywise = S_best
            best_sparsity_epoch = epoch


        print('Epoch:',epoch,'Best Cost:',cost_S_best,'Avg Cost:',avg_cost_S)
        print('Best score S:',S_score_best,' *** Mean score S:',np.mean(score_S),'*** D:',sparsity_value)        
        print(20*'-')
        
    
        scores_collection[cv_indx,epoch] = S_score_best
        avg_scores_collection[cv_indx,epoch]  = np.mean(score_S)

        sparsity_collection[cv_indx,epoch]  = sparsity_value
        avg_sparsity_collection[cv_indx,epoch]  = np.mean(S)

        cost_collection[cv_indx,epoch]  = cost_S_best
        avg_cost_collection[cv_indx,epoch]  = avg_cost_S
    

    S_best_tiled = np.tile(np.expand_dims(S_best,axis=0),(S.shape[0],1))
    # print(S_best.shape,graph_signal_tr.shape,S_best_tiled.shape)
    sparse_graph_signal_tr = S_best_tiled*graph_signal_tr
    post_trained_model = classifier.trainingS(sparse_graph_signal_tr,Y_training) ## Training the classifier with best sparse state vector
    score_sparse = classifier.inference(S_best_tiled,post_trained_model,sparse_graph_signal_tr,Y_training) # inference performance of best sparse state vector
    
    ####### Testing
    np.savetxt(file_path+'/sbest.txt',S_best, fmt="%f",delimiter=',')

    ## Proposed ERocket Sparsty
    S_best_tiled = np.tile(np.expand_dims(S_best,axis=0),(graph_signal_ts.shape[0],1))
    sparse_graph_signal_ts = S_best_tiled*graph_signal_ts
    test_score_sparse_post = classifier.inference(S_best_tiled,post_trained_model,sparse_graph_signal_ts,Y_test) # inference performance of best sparse state vector on the test dataset using post-trained model
    test_score_sparse_pre = classifier.inference(S_best_tiled,trained_model,sparse_graph_signal_ts,Y_test)    
    
    # Best Sparse and Score vectors independently
    ## Best Score
    S_best_score_tiled = np.tile(np.expand_dims(best_state_scorewise,axis=0),(graph_signal_ts.shape[0],1))
    sparse_graph_signal_ts_bestscore = S_best_score_tiled*graph_signal_ts
    test_best_score_sparse_post = classifier.inference(S_best_score_tiled,post_trained_model,sparse_graph_signal_ts_bestscore,Y_test) # inference performance of best sparse state vector on the test dataset using post-trained model
    test_best_score_sparse_pre = classifier.inference(S_best_score_tiled,trained_model,sparse_graph_signal_ts_bestscore,Y_test)    
    #### Training with best score and evaluating
    S_best_score_tiledt = np.tile(np.expand_dims(best_state_scorewise,axis=0),(graph_signal_tr.shape[0],1))
    sparse_graph_signal_tr = S_best_score_tiledt*graph_signal_tr
    post_trained_model_bestscore = classifier.trainingSbest(sparse_graph_signal_tr,Y_training) ## Training the classifier with best sparse state vector
    score_bestscore = classifier.inference(S_best_score_tiled,post_trained_model_bestscore,sparse_graph_signal_ts_bestscore,Y_test) # inference performance of best sparse state vector
    
    ## Best Sparsity
    S_best_sparsity_tiled = np.tile(np.expand_dims(best_state_sparsitywise,axis=0),(graph_signal_ts.shape[0],1))
    print(S_best_sparsity_tiled.shape,graph_signal_ts.shape)
    sparse_graph_signal_ts_bestsparsity = S_best_sparsity_tiled*graph_signal_ts
    test_best_score_sparse_post = classifier.inference(S_best_sparsity_tiled,post_trained_model,sparse_graph_signal_ts_bestsparsity,Y_test) # inference performance of best sparse state vector on the test dataset using post-trained model
    test_best_score_sparse_pre = classifier.inference(S_best_sparsity_tiled,trained_model,sparse_graph_signal_ts_bestsparsity,Y_test)    
    #### Training with best sparsity and evaluating
    S_best_sparsity_tiledt = np.tile(np.expand_dims(best_state_sparsitywise,axis=0),(graph_signal_tr.shape[0],1))
    sparse_graph_signal_tr = S_best_sparsity_tiledt*graph_signal_tr
    post_trained_model_bestsparsity = classifier.trainingSparbest(sparse_graph_signal_tr,Y_training) ## Training the classifier with best sparse state vector
    score_bestsparse = classifier.inference(S_best_score_tiled,post_trained_model_bestsparsity,sparse_graph_signal_ts_bestsparsity,Y_test) # inference performance of best sparse state vector
    

    ## Full states
    S_full = np.ones((1,arguments.num_kernels))
    S_full = np.tile(S_full,(graph_signal_ts.shape[0],1))
    test_score_full_pre = classifier.inference(S_full,trained_model,graph_signal_ts,Y_test) # inference performance of full state vector on the test dataset using pre-trained model
    test_score_full_post = classifier.inference(S_full,post_trained_model,graph_signal_ts,Y_test) # inference performance of full state vector on the test dataset using post-trained model
    
    ## Random Sparsity of States
    S_random1 = np.round(np.random.random((1,arguments.num_kernels)))
    S_random = np.tile(S_random1,(graph_signal_ts.shape[0],1))
    random_sparse_graph_signal_ts = S_random*graph_signal_ts
    test_score_random_post = classifier.inference(S_random,post_trained_model,random_sparse_graph_signal_ts,Y_test) # inference performance of best sparse state vector on the test dataset using post-trained model
    test_score_random_pre = classifier.inference(S_random,trained_model,random_sparse_graph_signal_ts,Y_test) # inference performance of full state vector on the test dataset using pre-trained model
    
    # Training with random state vector 0.5
    S_random = np.tile(S_random1,(graph_signal_tr.shape[0],1))
    randomsparse_graph_signal_tr = S_random*graph_signal_tr
    random_trained_model = classifier.trainingSR5(randomsparse_graph_signal_tr,Y_training) ## Training the classifier with best sparse state vector
    test_score_random_randmodel05 = classifier.inference(S_random,random_trained_model,random_sparse_graph_signal_ts,Y_test) # inference performance of best sparse state vector on the test dataset using post-trained model
    
    # Training with random state vector length of S_best
    S_randomD1 = np.zeros((1,arguments.num_kernels))
    S_randomD1[0,:int(np.sum(S_best))] = 1
    # print(S_randomD1.shape,np.sum(S_randomD1))
    np.random.shuffle(S_randomD1)
    S_randomD = np.tile(S_randomD1,(graph_signal_tr.shape[0],1))
    randomsparse_graph_signal_trD = S_randomD*graph_signal_tr
    random_trained_modelD = classifier.trainingSRD(randomsparse_graph_signal_trD,Y_training) ## Training the classifier with best sparse state vector
    test_score_random_randmodelD = classifier.inference(S_randomD,random_trained_modelD,graph_signal_ts,Y_test) # inference performance of best sparse state vector on the test dataset using post-trained model

    
    
    print(arguments.ds_name)
    print(10*'=','With full state vector',10*'=')
    print('Avg. Test on Full premodel:',test_score_full_pre)
    print('Avg. Test on Full postmodel:',test_score_full_post)

    print(10*'=','With random state vector',10*'=')
    print('Avg. Test on random sparsity premodel:',test_score_random_pre)
    print('Avg. Test on random sparsity postmodel:',test_score_random_post)
    print('Avg. Test on random sparsity random model 0.5:',test_score_random_randmodel05,np.sum(S_random1)/arguments.num_kernels)
    print('Avg. Test on random sparsity random model len S:',test_score_random_randmodelD,np.sum(S_randomD1)/arguments.num_kernels)

    print(10*'=','With best cost vector',10*'=')
    print('Avg. Test on Sparse postmodel:',test_score_sparse_post,np.sum(S_best)/arguments.num_kernels)
    print('Avg. Test on Sparse premodel:',test_score_sparse_pre,np.sum(S_best)/arguments.num_kernels)
    
    print(10*'=','With best score vector',10*'=')
    print('Best score:',best_score_sofar[0],'Sparsity:',best_score_sofar[1],'Cost:',best_score_sofar[2])
    print('Avg. Test on Best score on premodel:',test_best_score_sparse_pre,np.sum(best_state_scorewise)/arguments.num_kernels)
    print('Avg. Test on Best score on postmodel:',test_best_score_sparse_post,np.sum(best_state_scorewise)/arguments.num_kernels)
    print('Avg. Test on trained with Best score:',score_bestscore,np.sum(best_state_scorewise)/arguments.num_kernels)

    print(10*'=','With best sparsity vector',10*'=')
    print('Score:',best_sparsity_sofar[0],'Best Sparsity:',best_sparsity_sofar[1],'Cost:',best_sparsity_sofar[2])
    print('Avg. Test on Best sparsity on premodel:',test_best_score_sparse_pre,np.sum(best_state_sparsitywise)/arguments.num_kernels)
    print('Avg. Test on Best sparsity on postmodel:',test_best_score_sparse_post,np.sum(best_state_sparsitywise)/arguments.num_kernels)
    print('Avg. Test on trained with Best sparsity:',score_bestsparse,np.sum(best_state_sparsitywise)/arguments.num_kernels)

    test_results_[cv_indx,0] = test_score_full_pre
    test_results_[cv_indx,1] = test_score_full_post
 
    test_results_[cv_indx,2] = test_score_random_pre
    test_results_[cv_indx,3] = test_score_random_post
    test_results_[cv_indx,4] = test_score_random_randmodel05
    test_results_[cv_indx,5] = test_score_random_randmodelD
    test_results_[cv_indx,6] = np.sum(S_randomD1)/arguments.num_kernels
 
    test_results_[cv_indx,7] = test_score_sparse_post
    test_results_[cv_indx,8] = np.sum(S_best)/arguments.num_kernels
    test_results_[cv_indx,9] = test_score_sparse_pre
 
    test_results_[cv_indx,10] = best_score_sofar[0]
    test_results_[cv_indx,11] = best_score_sofar[1]
    test_results_[cv_indx,12] = best_score_sofar[2]
    test_results_[cv_indx,13] = test_best_score_sparse_pre
    test_results_[cv_indx,14] = test_best_score_sparse_post
    test_results_[cv_indx,15] = score_bestscore
    test_results_[cv_indx,16] = np.sum(best_state_scorewise)/arguments.num_kernels

    test_results_[cv_indx,17] = best_sparsity_sofar[0]
    test_results_[cv_indx,18] = best_sparsity_sofar[1]
    test_results_[cv_indx,19] = best_sparsity_sofar[2]
    test_results_[cv_indx,20] = test_best_score_sparse_pre
    test_results_[cv_indx,21] = test_best_score_sparse_post
    test_results_[cv_indx,22] = score_bestsparse
    test_results_[cv_indx,23] = np.sum(best_state_sparsitywise)/arguments.num_kernels

    test_results_[cv_indx,24] = best_score_epoch
    test_results_[cv_indx,25] = best_sparsity_epoch


### Saving results
# file_path = 'results/'+arguments.ds_name

# if not os.path.exists(file_path):
#     os.makedirs(file_path)
np.savetxt(file_path+'/results.txt',test_results_, fmt="%f",delimiter=',')
np.savetxt(file_path+'/scores_collection.txt',scores_collection, fmt="%f",delimiter=',')
np.savetxt(file_path+'/avg_scores_collection.txt',avg_scores_collection, fmt="%f",delimiter=',')
np.savetxt(file_path+'/sparsity_collection.txt',sparsity_collection, fmt="%f",delimiter=',')
np.savetxt(file_path+'/avg_sparsity_collection.txt',avg_sparsity_collection, fmt="%f",delimiter=',')
np.savetxt(file_path+'/cost_collection.txt',cost_collection, fmt="%f",delimiter=',')
np.savetxt(file_path+'/avg_cost_collection.txt',avg_cost_collection, fmt="%f",delimiter=',')

with open(file_path+'/commandline_args.txt', 'w') as f:
    json.dump(arguments.__dict__, f, indent=2)



    #     for sample_indx in range(n_samples):
    #         ##TODO: shuffle?
    #         sample = np.expand_dims(np.transpose(graph_signal_tr[sample_indx,:,1]),axis=1)
    #         sample_target = Y_training[sample_indx]-1 # Targets start from 1 not 0
    #         # Evolution
    #         new_S = signal_energy.evoluion(arguments,S,sample_target)
    #         # print(S,new_S)
    #         # Evaluation
    #         if epoch==0:
    #             best_states_current = best_states[epoch,:,:]
    #         else:
    #             best_states_current = best_states[epoch-1,:,:]

    #         current_pop_energy,evolved_pop_energy, current_states_energy = signal_energy.signal_energy(arguments,sample,sample_target,S,new_S,best_states_current)
    #         # Selection
    #         best_energy[epoch,sample_target], best_states[epoch,sample_target,:],S, max_sf, mean_sf = signal_energy.selection(current_pop_energy,evolved_pop_energy,S,new_S,sample_target,current_states_energy) #
    #         sf_dict_max[sample_target].append(max_sf)
    #         sf_dict_mean[sample_target].append(mean_sf)
    #         print('Target:',sample_target,max_sf,mean_sf)
    #         # sys.exit()

    #         if auto_save==True and mean_sf>best_states_overall[sample_target,-1]:
    #             best_states_overall[sample_target,:-1] = best_states[epoch,sample_target,:]
    #             best_states_overall[sample_target,-1] = mean_sf
    #             if np.mean(best_states_overall[:,-1]==1): # stop if mean sf is one for all classes
    #                 break_flag = True
    #             print('Updated best state')
    #         print('--------')
    #     # print('Epoch:....',best_energy[epoch,:])
    # # print(sf_dict_max,sf_dict_mean)
    # ## Test
    # if auto_save==False:
    #     best_states_overall[:,:-1] = best_states[epoch,:,:]
    # n_samples = graph_signal_ts.shape[0]
    # # confusion_matrix = np.zeros((C,C))
    # predictions = []
    # targets = []
    # for sample_indx in range(n_samples):
    #     sample = np.expand_dims(np.transpose(graph_signal_ts[sample_indx,:,1]),axis=1)        
    #     sample_target = Y_test[sample_indx]-1 # Targets start from 1 not 0
    #     predicted_class, confidence = signal_energy.signal_energy_test(arguments,sample,sample_target,best_states_overall,C)
    #     predictions.append(predicted_class)
    #     targets.append(sample_target)
    #     # confusion_matrix[sample_target,predicted_class]+=1
    #     print(sample_target,predicted_class,confidence)
    # # print(confusion_matrix)
    # print(confusion_matrix(targets,predictions))
    # print(accuracy_score(targets,predictions))
#         # -- RidgeClassifierCV training ----------------------------------------------------------
#         print('Classification...')
#         time_a = time.perf_counter()
#         classifier = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
#         classifier.fit(X_training_transform, Y_training)
#         time_b = time.perf_counter()
#         _timings[2, i] = time_b - time_a

#         # -- test --------------------------------------------------------------

#         time_a = time.perf_counter()
#         _results[i] = classifier.score(X_test_transform, Y_test)
#         time_b = time.perf_counter()
#         _timings[3, i] = time_b - time_a

#         print("Classification Done.")

# print('Saving the results...')
# # -- store results ---------------------------------------------------------

# results.loc[dataset_name, "accuracy_mean"] = _results.mean()
# results.loc[dataset_name, "accuracy_standard_deviation"] = _results.std()
# results.loc[dataset_name, "time_training_seconds"] = _timings.mean(1)[[0, 2]].sum()
# results.loc[dataset_name, "time_test_seconds"] = _timings.mean(1)[[1, 3]].sum()

# print(f"FINISHED".center(80, "="))

# results.to_csv(results_output_name)

# collective_results.write(ds_name+'\t'+model_+'\t'+str(nk)+'\t'+str(ethrs)+'\t'+ str(_results.mean())+'\t'+str(_results.std())+'\n')
# collective_results.flush()
# collective_results.close()