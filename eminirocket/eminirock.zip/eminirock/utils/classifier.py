
from sklearn.linear_model import RidgeClassifierCV
import numpy as np
from joblib import Parallel, delayed

def training(X,Y):
    model = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
    model.fit(X, Y)
    return model

def trainingS(X,Y):
    model = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
    model.fit(X, Y)
    return model



def trainingSparbest(X,Y):
    model = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
    model.fit(X, Y)
    return model

def trainingSbest(X,Y):
    model = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
    model.fit(X, Y)
    return model


def trainingSR5(X,Y):
    model = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
    model.fit(X, Y)
    return model

def trainingSRD(X,Y):
    model = RidgeClassifierCV(alphas = np.logspace(-3, 3, 10), normalize = True)
    model.fit(X, Y)
    return model

def scoring(model,X,Y):
    score = model.score(X, Y)
    return score

def inference(S,model,X,Y):
    # print(len(S.shape))
    if len(S.shape)==3:
        # print('i am in')
        NS = S.shape[2] # number of state vectors (population size)
        X = S*X # apply states to the inputs
        score = Parallel(n_jobs=int(NS/4),backend="threading")(delayed(scoring)(model,X[:,:,i],Y) for i in range(NS))
    elif len(S.shape)==2:
        score = scoring(model,X,Y)
    return np.asarray(score)

def costting(S,score):
    dcost_S  = np.sum(S[0,:,:],axis=0)/S.shape[1] # normalizing 
    # print('--------',dcost_S.shape,S.shape,dcost_S)

    ## TODO: introduce two type of cost function
    cost = 1 - (score - dcost_S) 
    # cost = 1-score
    # print('cost',cost,score)
    return cost, dcost_S