import argparse, copy
import numpy as np
import pandas as pd
import time
from scipy.spatial.distance import cdist

from sklearn.linear_model import RidgeClassifierCV
import matplotlib.pyplot as plt
from rocket_functions import generate_kernels, apply_kernels
from pygsp import graphs, filters, plotting


def graph_spectral(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test):
    print("Building the graph spectral ...")
    n_nodes = arguments.num_kernels
    adj_matrix = cdist(kernels_g, kernels_g, metric='euclidean')
    ## Normalized edge weights
    adj_matrix = adj_matrix/np.max(adj_matrix)
    ### Threshold Edges 
    adj_matrix = adj_matrix*(adj_matrix>arguments.edge_threshold)
    # Build  graph
    G = copy.deepcopy(graphs.Graph(adj_matrix))
    print('{} nodes, {} edges'.format(G.N, G.Ne))
    G.set_coordinates('ring2D')
    laplacian = G.L
    G.compute_fourier_basis()
    # Build graph signals
    # Training
    graph_signal_tr = np.expand_dims(X_training_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    graph_signal_tr = np.reshape(graph_signal_tr,(X_training_transform.shape[0],arguments.num_kernels,2))
    # Test
    graph_signal_ts = np.expand_dims(X_test_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    graph_signal_ts = np.reshape(graph_signal_ts,(X_test_transform.shape[0],arguments.num_kernels,2))
    # Visualization of Graph
    # print(graph_signal_tr[0,:,0])
    # G.plot()
    # plt.plot(G.U[:, 1])
    # G.plot_signal(G.U[:, 1])
    # print(graph_signal[0,:,0])
    # plt.plot(G.U[:, 1])
    # plt.plot(range(arguments.num_kernels), G.U[:, 1]*graph_signal[0,:,0],'r',range(arguments.num_kernels), G.U[:, 1],'g',range(arguments.num_kernels),graph_signal[0,:,0],'b')
    # plt.show()
    # print(laplacian)

    ## Prepare training and test data
    # X_training_transform1 = np.concatenate((G.U[:, 1]*graph_signal_tr[:,:,0],G.U[:, 1]*graph_signal_tr[:,:,1]),axis=1)
    # X_training_transform3 = np.concatenate((G.U[:, 3]*graph_signal_tr[:,:,0],G.U[:, 3]*graph_signal_tr[:,:,1]),axis=1)
    # X_training_transform2 = np.concatenate((G.U[:, 2]*graph_signal_tr[:,:,0],G.U[:, 2]*graph_signal_tr[:,:,1]),axis=1)
    # X_training_transform4 = np.concatenate((G.U[:, 4]*graph_signal_tr[:,:,0],G.U[:, 4]*graph_signal_tr[:,:,1]),axis=1)
    # X_training_transform = np.concatenate((X_training_transform1,X_training_transform2,X_training_transform3,X_training_transform4),axis=0)
    # Y_training = np.concatenate((Y_training,Y_training,Y_training,Y_training),axis=0)


    # X_test_transform1 = np.concatenate((G.U[:, 1]*graph_signal_ts[:,:,0],G.U[:, 1]*graph_signal_ts[:,:,1]),axis=1)
    # X_test_transform2 = np.concatenate((G.U[:, 2]*graph_signal_ts[:,:,0],G.U[:, 2]*graph_signal_ts[:,:,1]),axis=1)
    # X_test_transform3 = np.concatenate((G.U[:, 3]*graph_signal_ts[:,:,0],G.U[:, 3]*graph_signal_ts[:,:,1]),axis=1)
    # X_test_transform4 = np.concatenate((G.U[:, 4]*graph_signal_ts[:,:,0],G.U[:, 4]*graph_signal_ts[:,:,1]),axis=1)
    # X_test_transform = np.concatenate((X_test_transform1,X_test_transform2,X_test_transform3,X_test_transform4),axis=0)
    # Y_test = np.concatenate((Y_test,Y_test,Y_test,Y_test),axis=0)
    eigen_vector_indx = 1
    X_training_transform = np.concatenate((G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,0],G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,1]),axis=1)
    X_test_transform = np.concatenate((G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,0],G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,1]),axis=1)

    # X_training_transform = G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,0]
    # X_test_transform = G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,0]

    # X_training_transform = G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,0]
    # X_test_transform = G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,0]

    # print(Y_training.shape,Y_test.shape,X_training_transform.shape,X_test_transform.shape)
    print('Graph is ready.')
    
    return X_training_transform, X_test_transform
