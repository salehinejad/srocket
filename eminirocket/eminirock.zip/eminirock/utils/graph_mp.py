import torch as th
import networkx as nx
import dgl 
import numpy as np
import matplotlib.pyplot as plt
import argparse, copy
import pandas as pd
import time, sys
from scipy.spatial.distance import cdist
from sklearn.linear_model import RidgeClassifierCV
import matplotlib.pyplot as plt
from rocket_functions import generate_kernels, apply_kernels
from pygsp import graphs, filters, plotting
from tqdm import tqdm
from numba import njit, prange

def rocket_message_func(edges):
    return {'ppv':edges.src['ppv']*edges.data['w'], 'max':edges.src['max']*edges.data['w']}

def rocket_reduce_func(nodes):
#     print(nodes.mailbox['x0'])
    msgs_ppv = th.sum(nodes.mailbox['ppv'], dim=1)
    ppv_ = (1 - DAMP) / n_nodes + DAMP * msgs_ppv
    msgs_max = th.sum(nodes.mailbox['max'], dim=1)
    max_ = (1 - DAMP) / n_nodes + DAMP * msgs_max
    return {'ppv':ppv_, 'max':max_}


def graph_mp(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test):
    graph_vis = 'False'
    global DAMP
    global n_nodes
    DAMP = 0.85
    N_Iter_MP = 5 # number of MP iterations
    edge_w_thr = arguments.edge_threshold

    print("Building the graph ...")
    n_nodes = arguments.num_kernels

    edges_W = cdist(kernels_g, kernels_g, metric='euclidean') # edge weights
    ### Normalize edge weights
    edges_W = edges_W/np.max(edges_W)
    ### Threshold Edges 
    edges_W = edges_W*(edges_W>(edge_w_thr))
    ### Adj Matrix
    Adj_matrix = 1*(edges_W>0)

    #### NX Graph 
    G_nx = nx.from_numpy_matrix(Adj_matrix) # can use np.nonzero() instead
    ### DGL Graph
    G_dgl = dgl.from_networkx(G_nx)
    ### Edge weights
    G_dgl.edata['w'] = th.from_numpy(edges_W[edges_W!=0])

    

    print('Number of nodes: ',G_dgl.num_nodes())
    print('Number of edges: ',np.sum(Adj_matrix)/2)
    # print(G_nx.edges)
    # print(G_dgl)
    # print(G_dgl.edges())
    # print(G_dgl.edata['w'])

    if graph_vis=='True':
        nx.draw(G_dgl.to_networkx(), node_size=50, node_color=[[.5, .5, .5,]])
        plt.savefig('graph.png')

    ### Preparing placeholder for graph siganls
    #### Training
    graph_signal_tr = np.expand_dims(X_training_transform,axis=2) # n_samples x kernels x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    graph_signal_tr = np.reshape(graph_signal_tr,(X_training_transform.shape[0],arguments.num_kernels,2))
    #### Test
    graph_signal_ts = np.expand_dims(X_test_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    graph_signal_ts = np.reshape(graph_signal_ts,(X_test_transform.shape[0],arguments.num_kernels,2))


    print('Graph is built.')
    print('Message passing on the graph ...')
    for sample_indx in tqdm(range(graph_signal_tr.shape[0])): # for each training sample 
        ### Node signals for each training sample
        # print(graph_signal_tr[sample_indx,:,0].shape)
        
        G_dgl.ndata['ppv'] = th.from_numpy(graph_signal_tr[sample_indx,:,0]) # PPV
        G_dgl.ndata['max'] = th.from_numpy(graph_signal_tr[sample_indx,:,1]) # max
        ss = G_dgl.ndata['ppv']
        for mp_it in range(N_Iter_MP):
            G_dgl.send_and_recv(G_dgl.edges(),message_func=rocket_message_func,reduce_func=rocket_reduce_func)
            ### Normalization after each pass
            G_dgl.ndata['ppv'] = G_dgl.ndata['ppv']/th.max(G_dgl.ndata['ppv'])
            G_dgl.ndata['max'] = G_dgl.ndata['max']/th.max(G_dgl.ndata['max'])

            # print(th.sum(G_dgl.ndata['ppv']-ss))
            # print(G_dgl.ndata['max'])
        # print(10*'*')
        # print((G_dgl.ndata['ppv']).numpy())
        # print(np.concatenate(((G_dgl.ndata['ppv']).numpy(),(G_dgl.ndata['max']).numpy()),axis=0).shape)
        X_training_transform[sample_indx,:] = np.concatenate(((G_dgl.ndata['ppv']).numpy(),(G_dgl.ndata['max']).numpy()),axis=0) # Concatenate ppv,max
        # X_training_transform[sample_indx,:] = np.ravel([(G_dgl.ndata['ppv']).numpy(),(G_dgl.ndata['max']).numpy()],'F') # Concatenate every other ppv,max
    for sample_indx in tqdm(range(graph_signal_ts.shape[0])): # for each training sample 
        ### Node signals for each training sample
        # print(graph_signal_tr[sample_indx,:,0].shape)
        
        G_dgl.ndata['ppv'] = th.from_numpy(graph_signal_ts[sample_indx,:,0]) # PPV
        G_dgl.ndata['max'] = th.from_numpy(graph_signal_ts[sample_indx,:,1]) # max
        ss = G_dgl.ndata['ppv']
        for mp_it in range(N_Iter_MP):
            G_dgl.send_and_recv(G_dgl.edges(),message_func=rocket_message_func,reduce_func=rocket_reduce_func)
            ### Normalization after each pass
            G_dgl.ndata['ppv'] = G_dgl.ndata['ppv']/th.max(G_dgl.ndata['ppv'])
            G_dgl.ndata['max'] = G_dgl.ndata['max']/th.max(G_dgl.ndata['max'])

            # print(th.sum(G_dgl.ndata['ppv']-ss))
            # print(G_dgl.ndata['max'])
        # print(10*'*')
        X_test_transform[sample_indx,:] = np.concatenate(((G_dgl.ndata['ppv']).numpy(),(G_dgl.ndata['max']).numpy()),axis=0) # Concatenate ppv,max
        # X_test_transform[sample_indx,:] = np.ravel([(G_dgl.ndata['ppv']).numpy(),(G_dgl.ndata['max']).numpy()],'F') # Concatenate every other ppv,max

    print("MP graph done.")
    return X_training_transform, X_test_transform,edges_W



def graph_smp(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test):

    X_training_transform, X_test_transform, edges_W = graph_mp(arguments,kernels_g,X_training_transform,X_test_transform,Y_training,Y_test)
    
    print("GFT ...")
    G = 0
    G = copy.deepcopy(graphs.Graph(edges_W))
    print('{} nodes, {} edges'.format(G.N, G.Ne))
    G.set_coordinates('ring2D')
    laplacian = G.L
    G.compute_fourier_basis()
    graph_signal_tr = np.expand_dims(X_training_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    graph_signal_tr = np.reshape(graph_signal_tr,(X_training_transform.shape[0],arguments.num_kernels,2),order='F')
    # Test
    graph_signal_ts = np.expand_dims(X_test_transform,axis=2) # n_samples x : x feature_indx (d=2) print(graph_signal_tr[0,:,0])
    graph_signal_ts = np.reshape(graph_signal_ts,(X_test_transform.shape[0],arguments.num_kernels,2),order='F')
    
    eigen_vector_indx = 1
    X_training_transform = np.concatenate((G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,0],G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,1]),axis=1)
    X_test_transform = np.concatenate((G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,0],G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,1]),axis=1)

    # X_training_transform = G.U[:, eigen_vector_indx]*graph_signal_tr[:,:,0]
    # X_test_transform = G.U[:, eigen_vector_indx]*graph_signal_ts[:,:,0]
    print("GFT graph done.")

    return X_training_transform, X_test_transform
